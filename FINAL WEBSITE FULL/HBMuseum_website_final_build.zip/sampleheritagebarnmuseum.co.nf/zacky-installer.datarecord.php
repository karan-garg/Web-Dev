<?php /*

This file contains internal information for the Zacky Installer.
Do NOT change. Removing it might prevent you from using the installer 
on this installation in the future.

---
QlpoOTFBWSZTWT9iJ1wAAHlfgEAQQId/8CjgjBC/79+7MADsmDUBTyjyTATTamnpBoDRiYQip7VH
lNoynponoAI00wmmJoeg1MiT1PTao09TT1DQ0aaBkDRoDfU681XaiLEwFxQstmOL0JAWUxJeNKSd
6PkQ3g+qpzmGlaAmEUDU0aQHAV8pYzK/ImgoW7nVDGMCGBMF5M88Z2MU8E2SQPfEnMtRYeRMSqAu
UQBryoK7jVZYbYGaop5PWdlsaygcx7cD2uYho0hkO8JjWfJVT8pY65RSBBglGgUR00L3wTZXwbDE
a2cKvCIT4lAYB1oVW3okrKogDYfmypOsalHzNwKwqgSWAPBJlcXjuEAwciCn/1QxAC0FiE/vcXck
U4UJA/YidcA=

...

*/

Meet Patchwork, a sweet, retro quilt-style theme.  Patchwork comes in three color styles - Maude (default), Sunny and Babycakes - and supports custom menus, header image and backgrounds, and one widget-ready sidebar.


Version History:

v1.3 - Add support for Jetpack Infinite Scroll; fix broken mobile menu; fix wonky background transparency

v1.2.1 - Fixed broken graphic link for Babycakes theme style

v1.2 - 	Added graphic support for high-resolution (retina) displays.
		New responsive design for mobile devices.
		Minor bug fixes and style tweaks.
		Combined stylesheets for better efficiency.

v1.1.1 - Fixed @package declarations in custom-header.php, removed style/script registration in functions.php

v1.1 - Support for WP 3.4 features -- custom headers, custom backgrounds, theme customizer

v1.0.2 - Minor change to theme defaults; added PO/MO files for translation; fixed donation button in Theme Options

v1.0 - Hello, world!